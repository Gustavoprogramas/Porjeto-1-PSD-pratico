library ieee;
use ieee.std_logic_1164.all;

package pacote_ula is

    
    component full_adder
        port (
            A, B, Cin : in std_logic;
            S, Cout   : out std_logic
        );
    end component;

   
    component somador_4bits
        port (
            A, B     : in std_logic_vector(3 downto 0);
            Cin      : in std_logic;
            S        : out std_logic_vector(3 downto 0);
            Cout     : out std_logic;
            Overflow : out std_logic
        );
    end component;

    
    component multiplicador_2bits
        port (
            A, B      : in std_logic_vector(1 downto 0);
            resultado : out std_logic_vector(3 downto 0)
        );
    end component;

    
    component comparador
        port (
            a, b          : in std_logic_vector(3 downto 0);
            equ, grt, lst : out std_logic
        );
    end component;

end package pacote_ula;