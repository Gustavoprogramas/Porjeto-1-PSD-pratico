library ieee;
use ieee.std_logic_1164.all;
use work.pacote_ula.all;

entity ULA is
    port (
        A        : in  std_logic_vector(3 downto 0);
        B        : in  std_logic_vector(3 downto 0);
        AluOp    : in  std_logic_vector(2 downto 0);
        Result   : out std_logic_vector(3 downto 0);
        Zero     : out std_logic;
        Overflow : out std_logic;
        CarryOut : out std_logic;
        Equ      : out std_logic;
        Grt      : out std_logic;
        Lst      : out std_logic
    );
end ULA;

architecture structural of ULA is

    signal res_add, res_sub, res_and, res_or, res_not, res_mult : std_logic_vector(3 downto 0);
    signal b_inv : std_logic_vector(3 downto 0);
    signal c_add, c_sub, ov_add, ov_sub : std_logic;
    signal result_interno : std_logic_vector(3 downto 0);
    
   
    signal comp_equ, comp_grt, comp_lst : std_logic;

begin

  
    U_ADD: somador_4bits port map (
        A => A, B => B, Cin => '0', S => res_add, Cout => c_add, Overflow => ov_add
    );

  
    b_inv(0) <= not B(0); b_inv(1) <= not B(1); b_inv(2) <= not B(2); b_inv(3) <= not B(3);
    
    U_SUB: somador_4bits port map (
        A => A, B => b_inv, Cin => '1', S => res_sub, Cout => c_sub, Overflow => ov_sub
    );

    
    res_and(0) <= A(0) and B(0); res_and(1) <= A(1) and B(1); res_and(2) <= A(2) and B(2); res_and(3) <= A(3) and B(3);
    res_or(0)  <= A(0) or B(0);  res_or(1)  <= A(1) or B(1);  res_or(2)  <= A(2) or B(2);  res_or(3)  <= A(3) or B(3);
    
    res_not(0) <= not B(0);      res_not(1) <= not B(1);      res_not(2) <= not B(2);      res_not(3) <= not B(3);

   
    U_MULT: multiplicador_2bits port map (A => A(1 downto 0), B => B(1 downto 0), resultado => res_mult);
    
    
    U_COMP: comparador port map (a => A, b => B, equ => comp_equ, grt => comp_grt, lst => comp_lst);

    
    with AluOp select result_interno <=
        --"0000"   when "000", -- NOP
        res_and  when "001", -- AND
        res_or   when "010", -- OR
        res_not  when "011", -- NOT B
        res_add  when "100", -- ADD
        res_sub  when "101", -- SUB
        res_mult when "110", -- MUL
        "0000"   when others; 
        
    Result <= result_interno;

   
    
   
    Zero <= '1' when (result_interno = "0000" and AluOp /= "000") else '0';

    
	 
    with AluOp select CarryOut <= c_add when "100", c_sub when "101", '0' when others;
    with AluOp select Overflow <= ov_add when "100", ov_sub when "101", '0' when others;

    
    with AluOp select Equ <= comp_equ when "111", '0' when others;
    with AluOp select Grt <= comp_grt when "111", '0' when others;
    with AluOp select Lst <= comp_lst when "111", '0' when others;

end structural;