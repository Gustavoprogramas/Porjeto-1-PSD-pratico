library ieee;
use ieee.std_logic_1164.all;

entity multiplier_2bit is
    port (
        a      : in  std_logic_vector(1 downto 0);
        b      : in  std_logic_vector(1 downto 0);
        result : out std_logic_vector(3 downto 0)
    );
end multiplier_2bit;

architecture logic of multiplier_2bit is
    -- Fio interno para calcular o bit de sinal do resultado
    signal r3_int : std_logic;
begin
    
    --Multiplicação simples dos bits menos significativos
    result(0) <= a(0) and b(0);

    --Lógica XOR para cruzamento de sinais
    result(1) <= (a(1) and b(0)) xor (a(0) and b(1));

    --Lógica de sinal negativo da multiplicação
    r3_int <= (a(1) and (not b(1)) and b(0)) or ((not a(1)) and b(1) and a(0));
    result(3) <= r3_int;

    --Segue o sinal do MSB, com exceção do caso -2 * -2 = +4 (0100)
    result(2) <= r3_int or (a(1) and (not a(0)) and b(1) and (not b(0)));

end logic;