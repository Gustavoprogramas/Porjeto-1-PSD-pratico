library ieee;
use ieee.std_logic_1164.all;

entity tb_multiplicador_2bits is
    port (
        SW   : in  std_logic_vector(10 downto 0);
        LEDR : out std_logic_vector(3 downto 0)
    );
end tb_multiplicador_2bits;

architecture bhv of tb_multiplicador_2bits is
    component multiplicador_2bits
        port (
            A      : in  std_logic_vector(1 downto 0);
            B      : in  std_logic_vector(1 downto 0);
            resultado : out std_logic_vector(3 downto 0)
        );
    end component;
begin
    U1: multiplicador_2bits port map (
        A      => SW(8 downto 7),
        B      => SW(4 downto 3),
        resultado => LEDR(3 downto 0)
    );
end bhv;
