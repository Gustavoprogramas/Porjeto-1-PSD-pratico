library ieee;
use ieee.std_logic_1164.all;
use work.pacote_ula.all;

entity somador_4bits is
    port (
        A, B     : in std_logic_vector(3 downto 0);
        Cin      : in std_logic;
        S        : out std_logic_vector(3 downto 0);
        Cout     : out std_logic;
        Overflow : out std_logic
    );
end somador_4bits;

architecture structural of somador_4bits is
    signal carry : std_logic_vector(3 downto 0);
begin
    
    FA0: full_adder port map (A => A(0), B => B(0), Cin => Cin,      S => S(0), Cout => carry(0));
    FA1: full_adder port map (A => A(1), B => B(1), Cin => carry(0), S => S(1), Cout => carry(1));
    FA2: full_adder port map (A => A(2), B => B(2), Cin => carry(1), S => S(2), Cout => carry(2));
    FA3: full_adder port map (A => A(3), B => B(3), Cin => carry(2), S => S(3), Cout => carry(3));

    Cout <= carry(3);
    Overflow <= carry(3) xor carry(2);
end structural;